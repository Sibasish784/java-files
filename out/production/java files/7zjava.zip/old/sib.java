public class sib {
  public static void main(String[] args) {
    int x = 50;
    int y = 30;
    System.out.println(x % y);
  }
}

