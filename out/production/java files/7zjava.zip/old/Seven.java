import java.util.*;

 class Seven
 {
   public static void main(String args[])
   { 
     int num;
     Scanner sc = new Scanner(System.in);
     System.out.println("Enter number :");
     num =sc.nextInt();
     int check = num/2;
     if(check==0){
       System.out.println("The number is a even number");
      }
      else{
    System.out.println("The number is a odd number");
   }
 }
}