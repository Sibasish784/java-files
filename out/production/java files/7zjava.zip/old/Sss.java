import java.util.*; 

class Sss {
  public static void main(String[] args) {
    Scanner myObj = new Scanner(System.in);
    String userName;
      
    System.out.println("Demo name"); 
    userName = myObj.nextLine();   
       
    System.out.println("Demo name: " + userName);        
  }
}
